const m = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
const h = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat","Sabtu"];
